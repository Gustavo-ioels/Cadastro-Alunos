import javax.swing.JOptionPane;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

public class Aplicacao {
    public static void main (String args[]) {
        // Descomentar uma das funcoes para alterar o visual 
        
        Interface entradaDados = new EntradaDadosJ (); // JOptionPane 
        //Interface entradaDados = new EntradaDadosP (); // Painel 
        
        int opcao;
        int idade; 
        int ano; 
        int quantidade; 
        
        // Objeto instanciando a classe CadastroAlunos 
        CadastroAlunos cad = new CadastroAlunos(); 
        
        do {
            // Opção que o usuário escolherá 
            opcao = entradaDados.lerOpcao ();
            
            switch (opcao) {
                case 1:
                    // Usuário entra com o nome 
                    String nome = entradaDados.lerNome ();
                    // Usuário entra com o RA 
                    String ra = entradaDados.lerRA ();
                    
                    // Testa a repetição de RA 
                    if (cad.repeticaoRA (ra) == false) {
                        System.out.println ("RA inválido!");
                        continue;
                    } 
                    
                    // Usuário entra com a idade 
                    idade = entradaDados.lerIdade ();
                    // Usuário entra com o ano 
                    ano = entradaDados.lerAno ();
                    // Usuário entra com a quantidade de disciplinas 
                    quantidade = entradaDados.lerQtdeDisciplinas ();
                    
                    // Array instanciado da classe Disciplina 
                    Disciplina disc[];
                    disc = new Disciplina[quantidade]; 
                    
                    // Usuário entra com as informações das disciplinas 
                    for (int i = 0; i < quantidade; i++) {
                        String disciplina = entradaDados.lerDisciplina ();
                        float nota = entradaDados.lerNota ();
                        disc[i] = new Disciplina (disciplina, nota);
                    }

                    // Insere os alunos
                    if (entradaDados.inserirOK () != false) {
                        Aluno aluno = new Aluno (nome, idade, ra, ano, disc);
                        JOptionPane.showMessageDialog (null, "Aluno (a) " + aluno.getNome () + " inserido com sucesso!\n");
                        cad.salvarAluno (aluno); 
                    }
                    break;
                    
                case 2:
                    // Remove os alunos
                    String removerRA = entradaDados.lerRemover ();
                    cad.removerAluno (removerRA); 
                    break;
                    
                case 3:
                    // Lista os alunos
                    cad.listarAlunos (); 
                    break;
                    
                case 4:
                    // Salva os alunos
                    cad.salvarDados (); 
                    break;
                    
                case 5:
                    // Carrega os alunos
                    cad.carregarDados (); 
                    break;

                case 6:
                    // Saí do programa 
                    JOptionPane.showMessageDialog (null, "Saindo...");
                    break;

                default:
                    // Opção inválida 
                    JOptionPane.showMessageDialog (null, "Opção inválida!");
                    break;
            }
        } while (opcao != 6);
    }
}

import java.io.Serializable;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

public class Aluno extends Pessoa implements Serializable {
    String ra;
    int serie;
    int quantidade;
    Disciplina disc[];

    // Construtores 
    Aluno (String nome, int idade, String ra, int serie, Disciplina disc[]) {
        super (nome, idade);
        setRa (ra);
        setSerie (serie);
        setDisciplinas (disc);
    }

    private void setRa (String ra) {
        this.ra = ra;   
    }   

    private void setSerie (int serie) {
        this.serie = serie;   
    }
    
    public String getRa () {
        return this.ra;
    }

    private int getSerie () {
        return this.serie;
    }

    public void setDisciplinas (Disciplina[] disc) {
        this.disc = disc;
    }
    
    public Disciplina[] getDisciplinas () {
        return this.disc;
    }
    
    public String toString () {
        return ("NOME: " + getNome () + ", IDADE: "+ getIdade () + ", RA: " + getRa () + ", ANO: " + getSerie ());
    }
}

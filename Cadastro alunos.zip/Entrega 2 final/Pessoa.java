import java.io.Serializable;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

public class Pessoa implements Serializable {
    private int idade;
    private NomePessoa nome;
    
    // Construtores 
    public Pessoa (String nome, int idade) {
        setIdade (idade);
        setNome (nome);
    }

    private void setIdade (int idade) {
        this.idade = idade;   
    }
    
    private void setNome (String nome) {
        this.nome = new NomePessoa (nome);   
    }
    
    protected String getNome () {
        return this.nome.getNome (); 
    }
    
    protected int getIdade () {
        return this.idade; 
    }
    
    public String getNomeInvertido () {
        return (this.nome.getNomeInvertido ());
    }
    
    public String toString () {
        return ("NOME: " + getNome () + ", IDADE: " + getIdade ());
    } 
}

import java.io.Serializable;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

public class ListaLigadaSimples implements IArmazenador, Serializable {
    No inicio, fim;
    int qtdNos;

    public ListaLigadaSimples () {
        setInicio (null);
        setFim (null);
        setQtdNos (0);
    }

    private void setInicio (No inicio) {
        this.inicio = inicio;
    }

    public No getInicio () {
        return (this.inicio);
    }

    public No getFim () {
        return (this.fim);
    }

    private void setFim (No fim) {
        this.fim = fim;
    }

    public int getQtd () {
        return this.qtdNos;
    }

    private void setQtdNos (int qtdNos) {
        this.qtdNos = qtdNos;
    }

    public boolean estaVazia () {
        boolean vazia = false; 
        
        if (getQtd () == 0 && getInicio () == null && getFim () == null) {
            vazia = true;
        }
        
        return vazia;
    }

    public void inserirInicio (Object elem) {
        No novo = new No(elem); 

        if (estaVazia ()) {
            setInicio (novo);
            setFim (novo);
        }
        else {
            novo.setProximo (inicio);
            setInicio (novo);
        }
        setQtdNos (getQtd () + 1);
    }

    public Object remover (int i){
        int k = 0;
        No prox = getInicio ();
        No ant = null;
        No aux = null;
        Object obj = null; 
        
        if (!estaVazia ()) {
            if (i == 0) {
                removerInicio ();
            }
            else {            
                // Percorre a lista até achar o nó antes do fim 
                while (prox != fim && i != k) {
                    // Percorremos a lista com uma váriavel recebendo o termo anterior, para que, ao encontrarmos o item desejado, o penúltimo item aponte para o próximo do atual
                    ant = prox; 
                    prox = prox.getProximo (); 
                    k++;
                }
                
                // Se o item que irá ser removido for o último, é intercalada a função de remover o último da lista
                if (prox == fim && i == k) { 
                    removerFim ();
                }
                // Fazemos o penúltimo item apontar para o próximo do atual 
                else if (i == k) { 
                    ant.setProximo (prox.getProximo ());
                    aux = getInicio ();
                    setQtdNos (getQtd () - 1);
                    obj = aux.getConteudo ();
                }    
            }
        }
        return obj;
    }

    public Object buscar (int i) {
        Object aux1 = null;
        
        if (!estaVazia ()) {
            int k = 0;
            No current = getInicio ();
            No aux = getInicio ();
            
            // Percorre a lista enquanto ela não for vazia e enquanto não for encontrado o índice desejado 
            while (current != null && k < i) { 
                current = current.getProximo ();
                k++;
            }
            
            if(k == i) {
                aux1 = current.getConteudo ();
            }
        }
        return aux1;
    }

    public void adicionar (Object elem) {
        No novo = new No (elem);
        
        if (estaVazia ()) {
            setInicio (novo);
            setFim (novo);
        }
        else {
            getFim ().setProximo (novo);
            setFim (novo);
        }
        setQtdNos (getQtd () + 1);
    }

    public Object removerInicio () {
        No aux = null;
        Object obj = null; 
        
        if (!estaVazia ()) {
            if ((getInicio () == getFim ())) {
                aux = getInicio ();
                setInicio (null);
                setFim (null);
            } 
            else {
                aux = getInicio ();
                setInicio (aux.getProximo ());
                aux.setProximo (null);
            }
            setQtdNos (getQtd () - 1);
            obj = aux.getConteudo ();
        }
        return (obj);
    }

    public Object removerFim () {
        No ant = getInicio ();
        No aux = null;
        Object obj = null; 
        
        if (!estaVazia()){
            if ((getInicio () == getFim ())){
                aux = getInicio();
                setInicio (null);
                setFim (null);
            } else {            
                // Percorre a lista até achar o nó antes do fim
                while (ant.getProximo () != fim) {
                    ant = ant.getProximo ();
                }
                ant.setProximo (null);
                aux = fim;
                setFim (ant);
            }
            setQtdNos (getQtd() - 1);
            obj = aux.getConteudo ();           
        }
        return obj;
    }
    
    public String toString (){
        String s = "";
        No current = getInicio ();
        
        // Percorrer a lista enquanto ela não for vazia e enquanto não for encontrado o índice desejado 
        while (current != null) { 
            s += current.getConteudo ().toString ();   
            current = current.getProximo ();
        }
        return s;
    }
}

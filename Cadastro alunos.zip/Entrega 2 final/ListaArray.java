import java.util.ArrayList;
import java.io.Serializable;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

public class ListaArray implements IArmazenador, Serializable {
    private ArrayList <Object> lista;

    public ListaArray () {
        setLista (new <Object> ArrayList ());
    }

    private ArrayList <Object> getLista () {
        return lista;
    }

    public int getQtd () {
        return lista.size ();
    }

    private void setLista (ArrayList <Object> lista) {
        this.lista = lista;
    }

    public void adicionar (Object obj) {
        lista.add (obj);
    }

    public Object remover (int i) {
        Object aux1 = null;

        if (buscar(i) != null) {
            aux1 = lista.get (i);
            lista.remove (i);
        }
        return aux1;
    }

    public Object buscar (int i) {
        Object aux1 = null;
        
        if (!lista.isEmpty () && (i >= 0 && i < getQtd ())){
            aux1 = lista.get (i);
        }
        return aux1;
    }

    public boolean estaVazia () {
        return (lista.isEmpty ());
    }

    public String toString () {
        String s = "";
        
        for (int i = 0; i < lista.size (); i++) {
            s += lista.get (i).toString ();
        }
        return s;
    }
}


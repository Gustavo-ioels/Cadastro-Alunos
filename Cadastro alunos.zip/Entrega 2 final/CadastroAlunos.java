import java.io.Serializable;
import java.io.*;
import javax.swing.JOptionPane;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

public class CadastroAlunos implements Serializable {
    IArmazenador armazenador;
    String lata = "";
    private Aluno cad;
    private Disciplina disc[];

    CadastroAlunos () {
        // Descomente somente uma das funções 
        
        //this.armazenador = new VetDin (); // VetDin
        //this.armazenador = new ListaArray (); // ArrayList
        this.armazenador = new ListaLigadaSimples (); // ListaLigada
    }
    
    // Para imprimir as materias, passamos como parâmetro o vetor 
    public void listarAlunos () {
        if (!armazenador.estaVazia ()) {
            for (int i = 0; i < armazenador.getQtd (); i++) {
                cad = (Aluno) armazenador.buscar (i); 
                System.out.println (cad);
                listarMaterias (cad, disc); 
            }
        }
        else {
            System.out.println ("Não há ninguém para listar!");
        }
    }
    
    // Acessamos o array para verificar se há matérias listadas 
    public void listarMaterias (Aluno cad, Disciplina[] disc) {
        for (int j = 0; j < cad.disc.length; j++) {
            if ((cad.disc[j] != null)) { 
                System.out.println (cad.disc[j]); 
            }
        }
    } 
    
    // Verifica se o RA existe na lista, e remove 
    public void removerAluno (String removerRA) {
        Aluno alunoAux = null;
        int find = 0;

        if (!armazenador.estaVazia ()) { 
            for (int i = 0; i < armazenador.getQtd (); i++) {
                alunoAux = (Aluno) armazenador.buscar (i);
                if (alunoAux.getRa ().equals (removerRA)) {
                    System.out.println ("Aluno(a) " + alunoAux.getNome() + " removido(a) com sucesso");
                    armazenador.remover (i);
                    find = 1;
                }
            } 
            if (find == 0) { 
                JOptionPane.showMessageDialog (null, "RA inválido");
            }
        }   
        else  {
            JOptionPane.showMessageDialog (null, "Não há ninguém para remover!");
        }
    }

    // Funções que salvam os alunos inscritos 
    public void salvarAluno (Aluno aluno) {
        armazenador.adicionar (aluno);
    }

    public void salvarDados () {
        if (!armazenador.estaVazia ()) { // Se cadastro nao estiver vazio
            ArquivoBinario ab = new ArquivoBinario ();
            lata = JOptionPane.showInputDialog("Com qual nome deseja salvar o arquivo?");
            if(lata != null){
            ab.gravarObj (armazenador, lata);
            JOptionPane.showMessageDialog (null, "O arquivo foi salvo com sucesso!");
            }else{
                JOptionPane.showMessageDialog (null, "Insira um nome para o arquivo!");
            }
        }  
        else  {
            JOptionPane.showMessageDialog (null, "Não há nada para salvar!");
        }
        
        ArquivoBinario ab = new ArquivoBinario ();
        ab.gravarObj (armazenador,lata);
    }

    // Função que carrega os alunos inscritos 
    public void carregarDados () {
        ArquivoBinario ab = new ArquivoBinario (); 
        IArmazenador aux = (IArmazenador) ab.lerObj (lata);
        String lataAux = "";
        lata = JOptionPane.showInputDialog("Qual o nome do arquivo salvo?");
        if (lata != null) { 
            JOptionPane.showMessageDialog (null, "O arquivo foi carregado com sucesso!");
            armazenador = (IArmazenador) ab.lerObj (lata);
        }
        else {
            JOptionPane.showMessageDialog (null, "Não há nada para carregar!");
        }
    }

    // Verifica se um RA já foi inscrito 
    public boolean repeticaoRA (String ra) {
        Aluno alunoAux = null;
        boolean teste = true;
        
        if (!armazenador.estaVazia ()) { 
            for(int i = 0; i < armazenador.getQtd(); i++){
                alunoAux = (Aluno) armazenador.buscar (i);
                
                if (alunoAux.getRa ().equals (ra)) 
                    teste = false;
            }
        }    
        return teste;
    }
}

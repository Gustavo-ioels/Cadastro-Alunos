/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

public interface Interface {
    public int lerOpcao();
    public String lerNome(); 
    public String lerRA();
    public int lerIdade(); 
    public int lerQtdeDisciplinas();
    public String lerDisciplina();
    public float lerNota();
    public int lerAno();
    public String lerRemover();
    public boolean inserirOK();
}

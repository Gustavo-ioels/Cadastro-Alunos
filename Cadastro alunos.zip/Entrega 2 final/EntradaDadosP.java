import java.util.Scanner;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

// EntradaDadosJ se refere à Painel 
public class EntradaDadosP implements Interface {
    Scanner scanner = new Scanner(System.in);
    
    static String aux = null; 
    
    int end = 0;

    public int lerOpcao () {
        int opcao = 0;
        boolean retornar = false;
        
        do {
            try {
                System.out.println ("Cadastro Alunos: \n1- INSERIR\n2- REMOVER\n3- LISTAR\n4- SALVAR\n5- CARREGAR\n6- SAIR");
                aux = scanner.nextLine ();
                opcao = Integer.parseInt (aux);
                retornar = true;
            } 
            catch (NumberFormatException e) {
                // Cancelar 
                if (aux == null) { 
                    System.out.println ("Saindo...");
                } 
                // Espaço vazio 
                else if (aux.trim ().isEmpty ()) { 
                    System.out.println ("Digite uma opção!");
                }
                // Valor inválido 
                else { 
                    System.out.println ("Digite um valor válido!");
                }
            }
        } while (!retornar);

        return(opcao);
    }

    public String lerNome () {
        String nome = null;
        boolean retornar = false;

        do {
            try {
                System.out.println ("Qual o NOME do aluno?");
                nome = scanner.nextLine ();
                
                // Cancelar 
                if (nome == null) { 
                    System.out.println ("Cadastro cancelado!");
                } 
                // Espaço vazio 
                else if (nome.trim ().isEmpty ()) { 
                    System.out.println ("Digite um nome!");
                } 
                // Caso digite números 
                else if(!nome.matches("^[a-zA-Z\\s]*$")){ 
                    System.out.println ("Digite apenas letras no nome!");
                }
                else {
                    retornar = true;
                }
            } 
            catch (Exception e) {
                System.out.println ("Erro: " + e.getMessage());
            }
        } while (!retornar);

        return nome;
    }

    public String lerRA () {
        String ra = null;
        boolean retornar = false;

        do {
            try {
                System.out.println ("Qual o RA do aluno?");
                ra = scanner.nextLine ();
                
                // Cancelar 
                if (ra == null) { 
                    System.out.println ("Cadastro cancelado!");
                } 
                // Espaço vazio 
                else if (ra.trim ().isEmpty ()) { 
                    System.out.println ("Digite um RA!");
                } 
                // Caso digite letras 
                else if (!ra.matches ("^\\d+$")) {
                    System.out.println ("Digite apenas números no RA!");
                } 
                else {
                    retornar = true;
                }
            } 
            catch (Exception e) {
                System.out.println ("Erro: " + e.getMessage());
            }
        } while (!retornar);

        return ra;
    }

    public int lerIdade () { 
        int idade = 0; 
        boolean retornar = false;
        
        do {
            try {
                System.out.println ("Qual a IDADE do aluno?");
                aux = scanner.nextLine ();
                idade = Integer.parseInt(aux);
                
                if (idade <= 0) {
                    System.out.println ("Apenas números inteiros positivos na idade!");
                }
                else {
                    retornar = true;
                }
            }
            catch (NumberFormatException e) {
                // Cancelar 
                if (aux == null) { 
                    System.out.println ("Cadastro cancelado!");
                }
                // Espaço vazio 
                else if (aux.trim ().isEmpty ()) { 
                    System.out.println ("Digite a idade!");
                }
                // Valor inválido 
                else {
                    System.out.println ("Digite apenas números inteiros positivos na idade!");
                }
            }
        } while (!retornar);

        return idade;
    }

    public int lerQtdeDisciplinas () { 
        int qtde = 0;
        boolean retornar = false;
        
        do {
            try {
                System.out.println ("Quantas DISCIPLINAS o aluno cursa?");
                aux = scanner.nextLine ();
                qtde = Integer.parseInt (aux);
                
                if (qtde <= 0) {
                    System.out.println ("Digite apenas números inteiros positivos na disciplina!");
                }
                else {
                    retornar = true;
                }
            }
            catch (NumberFormatException e) {
                // Cancelar 
                if (aux == null) { 
                    System.out.println ("Cadastro cancelado!");
                }
                // Espaço vazio 
                else if (aux.trim ().isEmpty ()) { 
                    System.out.println ("Digite a quantidade de disciplinas!");
                }
                // Valor inválido 
                else {
                    System.out.println ("Digite apenas números inteiros positivos na disciplina!");
                }
            }
        } while (!retornar);

        return qtde;
    }

    public String lerDisciplina () {
        String disciplina = null;
        boolean retornar = false;
        
        do {
            try {
                System.out.println ("Qual o NOME da DISCIPLINA?");
                disciplina = scanner.nextLine ();
                
                // Cancelar 
                if (disciplina == null) { 
                    System.out.println ("Cadastro cancelado!");
                }
                // Caso digite números 
                else if (!disciplina.matches("^[a-zA-Z\\s]*$")) {
                   System.out.println ("Digite apenas letras na disciplina!");                  
                } 
                // Espaço vazio 
                else if (disciplina.trim ().isEmpty ()) { 
                    System.out.println ("Digite o nome da disciplina!");
                } 
                else {
                    retornar = true;
                }
            }
            catch (NumberFormatException e) {
                if (disciplina.trim ().isEmpty ()){
                    System.out.println ( "Erro: " + e.getMessage());
                }
            }
        } while (!retornar);

        return disciplina;
    } 

    public float lerNota () { 
        float nota = -1;
        boolean retornar = false;
        
        do {
            try {
                System.out.println ("Qual a NOTA do aluno?");
                aux = scanner.nextLine ();

                nota = Float.parseFloat (aux);
                
                // Nota com valor inválido 
                if ((nota <  0) || (nota > 10)) {
                    System.out.println ("Digite números de 0 até 10!");                   
                } else {
                    retornar = true;
                }
            }
            catch (Exception e) {
                // Cancelar 
                if (aux == null) { 
                    System.out.println ("Cadastro cancelado!");
                }
                // Espaço vazio 
                else if (aux.trim ().isEmpty ()){ 
                    System.out.println ("Digite a nota do aluno!");
                } 
                // Valor inválido 
                else {
                    System.out.println ("Digite números de 0 até 10!");
                }
            }
        } while (!retornar);

        return nota;
    }

    public int lerAno () { 
        int ano = 0;
        boolean retornar = false;
        
        do {
            try {
                System.out.println ("Qual o PERÍODO do aluno?");
                aux = scanner.nextLine ();
                ano = Integer.parseInt (aux);
                
                if (ano <= 0) {
                    System.out.println ("Digite apenas números inteiros positivos no período!");
                } 
                else {
                    retornar = true;
                }
            } catch (NumberFormatException e) {
                // Cancelar 
                if (aux == null) { 
                    System.out.println ("Cadastro cancelado!");
                }
                // Espaço vazio 
                else if (aux.trim ().isEmpty ()) { 
                    System.out.println ("Digite o período do aluno!");
                }
                // Valor inválido 
                else {
                    System.out.println ("Digite apenas números inteiros positivos no período!");
                }
            }
        } while (!retornar);

        return ano;
    }
    
    public String lerRemover () {
        String removerRA = null;
        boolean retornar = false;
        
        do {
            try {
                System.out.println ("Qual o RA do aluno?");
                removerRA = scanner.nextLine ();
                
                // Cancelar 
                if (removerRA == null) { 
                    System.out.println ("Cadastro cancelado!");
                }
                
                // Espaço vazio 
                else if (removerRA.trim ().isEmpty ()) { 
                    System.out.println ("Digite um RA!");
                } 
                else {
                    retornar = true;
                }
            }
            catch (NumberFormatException e) {
                if (removerRA.trim ().isEmpty ())
                    System.out.println ("Erro: " + e.getMessage());
            }
        } while (!retornar);
        
        return removerRA;
    } 

    public boolean inserirOK () {
        boolean ok = true;

        if(end == 1) {
            ok = false;
        }
        end = 0;
        
        return ok;
    }
}


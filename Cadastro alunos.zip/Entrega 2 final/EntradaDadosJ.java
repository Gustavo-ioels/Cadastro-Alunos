import javax.swing.JOptionPane;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

// EntradaDadosJ se refere à JOptionPane 
public class EntradaDadosJ implements Interface {
    String aux = null; 
    
    public static int end = 0;

    public int lerOpcao () {
        int opcao = 0;
        boolean retornar = false;
        
        while (!retornar && end != 1) {
            try {
                aux = JOptionPane.showInputDialog ("Cadastro Alunos: \n1- INSERIR\n2- REMOVER\n3- LISTAR\n4- SALVAR\n5- CARREGAR\n6- SAIR");
                opcao = Integer.parseInt (aux);
                
                if (opcao <= 0) {
                    JOptionPane.showMessageDialog (null,"Digite um valor válido!");
                }
                else {
                    retornar = true;
                }
                
            } 
            catch (NumberFormatException e) {
                if (aux == null) { 
                    // Cancelar 
                    JOptionPane.showMessageDialog (null,"Saindo...");
                    System.exit (0);
                } 
                // Espaço vazio 
                else if (aux.trim ().isEmpty ()) { 
                    JOptionPane.showMessageDialog (null,"Digite uma opção!");
                }
                // Valor inválido 
                else {
                    JOptionPane.showMessageDialog (null,"Digite um valor válido!");
                }
            }
        }
        return (opcao);
    }

    public String lerNome () {
        String nome = null;
        boolean retornar = false;

        while (!retornar && end != 1) {
            try {
                nome = JOptionPane.showInputDialog ("Qual o NOME do aluno?");
                
                // Cancelar 
                if (nome == null) { 
                    JOptionPane.showMessageDialog (null,"Cadastro cancelado!");
                    end = 1;
                } 
                // Espaço vazio 
                else if (nome.trim ().isEmpty ()) { 
                    JOptionPane.showMessageDialog (null,"Digite um nome!");
                }
                // Caso digite números 
                else if(!nome.matches("^[a-zA-Z\\s]*$")){
                    JOptionPane.showMessageDialog (null,"Digite apenas letras no nome!");
                }
                else {
                    retornar = true;
                }
            } 
            catch (Exception e) {
                JOptionPane.showMessageDialog (null, "Erro: " + e.getMessage());
            }
        }
        return nome;
    }

    public String lerRA () {
        String ra = null;
        boolean retornar = false;

        while (!retornar && end != 1) {
            try {
                ra = JOptionPane.showInputDialog ("Qual o RA do aluno?");
                
                // Cancelar 
                if (ra == null) { 
                    JOptionPane.showMessageDialog (null,"Cadastro cancelado!");
                    end = 1;
                } 
                // Espaço vazio 
                else if (ra.trim ().isEmpty ()) { 
                    JOptionPane.showMessageDialog (null,"Digite um RA!");
                }
                // Caso digite letras 
                else if (!ra.matches ("^\\d+$")){
                    JOptionPane.showMessageDialog(null, "Digite apenas números no RA!");
                } 
                else {
                    retornar = true;
                }
            } 
            catch (Exception e) {
                JOptionPane.showMessageDialog (null, "Erro: " + e.getMessage());
            }
        }
        return ra;
    }

    public int lerIdade () { 
        int idade = 0; 
        boolean retornar = false;
        
        while (!retornar && end != 1) {
            try {
                aux = JOptionPane.showInputDialog ("Qual a IDADE do aluno?");
                idade = Integer.parseInt (aux);
                
                if (idade <= 0) {
                    JOptionPane.showMessageDialog (null, "Apenas números inteiros positivos na idade!");
                }
                else {
                    retornar = true;
                }
            }
            catch (NumberFormatException e) {
                // Cancelar 
                if (aux == null) { 
                    JOptionPane.showMessageDialog (null, "Cadastro cancelado!");
                    end = 1;
                }
                // Espaço vazio 
                else if (aux.trim ().isEmpty ()) {  
                    JOptionPane.showMessageDialog (null, "Digite a idade!");
                }
                // Valor inválido
                else {
                    JOptionPane.showMessageDialog (null, "Digite apenas números inteiros positivos na idade!");
                }
            }
        }
        return idade;
    }

    public int lerQtdeDisciplinas () { 
        int qtde = 0;
        boolean retornar = false;
        
        while (!retornar && end != 1) {
            try{
                aux = JOptionPane.showInputDialog ("Quantas DISCIPLINAS o aluno cursa?");
                qtde = Integer.parseInt (aux);
                
                if (qtde <= 0) {
                    JOptionPane.showMessageDialog (null, "Digite apenas números inteiros positivos na disciplina!");
                }
                else {
                    retornar = true;
                }
            }
            catch (NumberFormatException e) {
                // Cancelar 
                if (aux == null){ 
                    JOptionPane.showMessageDialog (null, "Cadastro cancelado!");
                    end = 1;
                }
                // Espaço vazio 
                else if (aux.trim ().isEmpty ()) {  
                    JOptionPane.showMessageDialog (null, "Digite a quantidade de disciplinas!");
                }
                // Valor inválido
                else {
                    JOptionPane.showMessageDialog (null, "Digite apenas números inteiros positivos na disciplina!");
                }
            }
        }
        return qtde;
    }

    public String lerDisciplina () {
        String disciplina = null;
        boolean retornar = false;
        
        while (!retornar && end != 1) {
            try {
                disciplina = JOptionPane.showInputDialog ("Qual o NOME da DISCIPLINA?");

                // Cancelar 
                if (disciplina == null) { 
                    JOptionPane.showMessageDialog (null, "Cadastro cancelado!");
                    end = 1;
                }
                // Caso digite números  
                else if (!disciplina.matches("^[a-zA-Z\\s]*$")) {
                   JOptionPane.showMessageDialog(null, "Digite apenas letras na disciplina!");                  
                } 
                // Espaço vazio 
                else if (disciplina.trim ().isEmpty ()) { 
                    JOptionPane.showMessageDialog (null, "Digite o nome da disciplina!");
                } 
                else {
                    retornar = true;
                }
            }
            catch (NumberFormatException e) {
                if (disciplina.trim ().isEmpty ())
                    JOptionPane.showMessageDialog (null, "Erro: " + e.getMessage());
            }
        }
        return disciplina;
    } 

    public float lerNota () { 
        float nota = -1;
        boolean retornar = false;
        
        while (!retornar && end != 1){
            try {
                aux = JOptionPane.showInputDialog ("Qual a NOTA do aluno?");
                nota = Float.parseFloat(aux);
                
                if ((nota <  0) || (nota > 10)) {
                    JOptionPane.showMessageDialog (null, "Digite números de 0 até 10!");                   
                }
                else {
                    retornar = true;
                }
            }
            catch (Exception e) {
                // Cancelar 
                if (aux == null) { 
                    JOptionPane.showMessageDialog (null, "Cadastro cancelado!");
                    end = 1;
                }
                // Espaço vazio 
                else if (aux.trim ().isEmpty ()){  
                    JOptionPane.showMessageDialog (null, "Digite a nota do aluno!");
                }
                else {
                    JOptionPane.showMessageDialog (null, "Digite números de 0 até 10!");    
                }
            }
        }
        return nota;
    }

    public int lerAno () { 
        int ano = 0;
        boolean retornar = false;
        
        while (!retornar && end !=1 ) {
            try {
                aux = JOptionPane.showInputDialog ("Qual o PERÍODO do aluno?");
                ano = Integer.parseInt (aux);
                
                if(ano <= 0) {
                    JOptionPane.showMessageDialog (null, "Digite apenas números inteiros positivos no período!");
                }
                else {
                    retornar = true;
                }  
            }
            catch (NumberFormatException e) {
                // Cancelar 
                if (aux == null) { 
                    JOptionPane.showMessageDialog (null, "Cadastro cancelado!");
                    end = 1;
                }
                // Espaço vazio 
                else if (aux.trim ().isEmpty ()) { 
                    JOptionPane.showMessageDialog (null, "Digite o período do aluno!");
                }
                else {
                    JOptionPane.showMessageDialog (null, "Digite apenas números inteiros positivos no período!");
                }
            }
        }
        return ano;
    }
    
    public String lerRemover () {
        String removerRA = null;
        boolean retornar = false;
        
        while (!retornar && end != 1) {
            try {
                removerRA = JOptionPane.showInputDialog ("Qual o RA do aluno?");
                
                // Cancelar 
                if (removerRA == null) { 
                    JOptionPane.showMessageDialog (null,"Cadastro cancelado!");
                    end = 1;
                }
                // Espaço vazio 
                else if (removerRA.trim ().isEmpty ()) { 
                    JOptionPane.showMessageDialog (null,"Digite um RA!");
                } 
                else {
                    retornar = true;
                }
            }
            catch (NumberFormatException e) {
                if (removerRA.trim ().isEmpty ()) {
                    JOptionPane.showMessageDialog (null,"Erro: " + e.getMessage());
                }
            }
        }
        return removerRA;
    } 
    
    public boolean inserirOK () {
        boolean ok = true;
        
        if (end == 1) {
            ok = false;
        }
        end = 0;
        
        return ok;
    }
}


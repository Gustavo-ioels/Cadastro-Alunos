import java.io.*;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

// Escreve o objeto no arquivo
public class ArquivoBinario {
    public void gravarObj (Object objeto, String nomeArq) {
        ObjectOutputStream output = null;
        
        try {
            File file = new File (nomeArq);
            output = new ObjectOutputStream (new FileOutputStream (file));
            output.writeObject(objeto); 
        } 
        catch (Exception e) {
            System.out.println (e.toString ());
        } 
        finally {
            try {
                output.close ();
            } 
            catch (Exception ex) {
                // Não faz nada
            }
        }
    }

    // Lê o objeto do arquivo
    public Object lerObj (String nomeArq) {
        Object objeto = null;
        ObjectInputStream input = null;
        
        try {
            File file = new File (nomeArq);
            input = new ObjectInputStream (new FileInputStream (file));
            objeto = (Object) input.readObject ();  
        }
        catch (Exception e) {
            System.out.println (e.toString ());
        } 
        finally {
            try {
                input.close ();
            } 
            catch (Exception ex) {
                // Não faz nada
            }
        }
        return objeto;
    }
}

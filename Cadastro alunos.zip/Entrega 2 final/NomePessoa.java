import java.io.Serializable;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

public class NomePessoa implements Serializable{
    private Texto nome;

    // Construtores 
    public NomePessoa (String nome) {
        setNome (nome);
    }

    public String getNome () {
        return this.nome.getTxt ();
    }

    private void setNome (String nome) {
        this.nome = new Texto (nome);
    }

    public int getQtdePalavras () {
        return this.nome.getQtdePalavras ();
    }
    
    public String getNomeInvertido () {
        return this.nome.inverterTexto ();
    }

    public String getNomeBiblio () {
        String vts[] = this.nome.getTxt ().split (" ");
        int qtd = vts.length;
        String sBib = vts[qtd-1] + ", "; 
        
        for (int i = 0; i < (qtd - 1); i++) {
            String pal = vts[i].toLowerCase (); 
            if (!verificaStr (pal)) { 
                sBib = sBib + vts[i].toUpperCase ().charAt (0) + ". ";
            }
        }
        setNome(sBib);
        
        return sBib;
    }

    private boolean verificaStr (String s) {
        final String sRet[] = {"da", "de", "do", "di", "das", "dos", "e",};

        for (int i = 0; i < sRet.length; i++) {
            if (sRet[i].equals (s)) {
                return true;
            }
        }
        return false;
    }

    public String toString () {
        return this.nome.toString ();
    }
}


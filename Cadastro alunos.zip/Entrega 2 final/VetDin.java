import java.io.Serializable;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

public class VetDin implements IArmazenador, Serializable {
    private Object array[]; 
    
    private int qtd;

    public VetDin () {
        setArray (null);
        setQtd (0);
    }

    private Object[] getArray () {
        return array;
    }

    public int getQtd () {
        return qtd;
    }

    private void setArray (Object[] array) {
        this.array = array;
    }

    private void setQtd (int qtd) {
        this.qtd = qtd;
    }

    public void adicionar (Object obj) {
        // Caso ele seja o primeiro elemento 
        if (array == null){  
            setArray (new Object[1]);
            array[0] = obj; 
            setQtd (getQtd () + 1);
        }
        // Demais elementos
        else { 
            // Cria um vetor auxiliar com mais um elemento
            Object aux[] = new Object[array.length + 1];

            // Copia todos elementos do vetor para aux
            copiar (array, aux);

            // Insere um novo elemento 
            aux[aux.length - 1] = obj;

            // O vetor auxiliar passa a ser o atual
            setArray (aux);

            // Incrementa um contador 
            setQtd (getQtd () + 1);
        }
    }

    public Object remover (int i) {
        Object aux1 = null;
        
        if (buscar (i) != null) {
            aux1 = array[i];
            array[i] = null;

            if (getQtd() > 1) {
                // Cria um vetor auxiliar com mais um elemento
                Object aux[] = new Object[array.length-1];

                // Copia todos elementos do vetor para aux
                copiar (array, aux);

                // Insere um novo elemento 
                setArray (aux);
                
                // Incrementa um contador 
                setQtd(getQtd () - 1);
            } 
            else {
                // Caso tenha acabado os elementos
                setArray (null);
                setQtd (0);
            }
        }
        return aux1;
    }

    public Object buscar (int i) {
        Object aux1 = null;
        
        if (array != null && (i >= 0 && i < getQtd ())) {
            aux1 = array[i];
        }
        return aux1;
    }

    public boolean estaVazia () {
        return (getQtd () == 0 && getArray () == null);
    }

    private void copiar (Object origem[], Object destino[]) {
        // Copia todos os itens 
        int i, k = 0;
        
        for (i = 0; i < origem.length; i++) {
            if (origem[i] != null) {
                destino[k] = origem[i];
                k++;
            }
        }       
    }

    public String toString () {
        String s = "";
        
        if (array != null) {
            for (int i = 0; i < array.length; i++){
                s += array[i].toString ();
            }
        }
        return s;
    }
}

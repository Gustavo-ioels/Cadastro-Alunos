import java.io.Serializable;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

public class No implements Serializable{
    Object conteudo; 
    No proximo; 
    
    // Construtores 
    public No (Object conteudo) {
        setConteudo (conteudo);
        setProximo (null);
    }

    public void setConteudo (Object conteudo) {
        this.conteudo = conteudo;
    }

    public void setProximo (No proximo) {
        this.proximo = proximo;
    }

    public Object getConteudo () {
        return (this.conteudo);
    }

    public No getProximo () {
        return (this.proximo);
    }

    public String toString () {
        return (conteudo.toString ());
    }
}

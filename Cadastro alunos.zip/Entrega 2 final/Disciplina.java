import java.io.Serializable;

/*
 * Grupo: 
 * Gustavo Leite Ioels RA00321528
 * Pedro França de Godoi RA00318693
 * Caio Perreira Guimarães RA00318945
 * Pedro Henrique da Costa Manso Saraiva RA00321605
 */

public class Disciplina implements Serializable {
    private float nota;
    String materia;
    Texto nomeDisc;
    Disciplina disc;

    // Construtores 
    public Disciplina (String disciplina, float nota) {
        setDisciplina (disciplina);
        setNota (nota);
    }

    public void setDisciplina (String disciplina) {
        this.nomeDisc = new Texto (disciplina);
    }

    public String getDisciplina () {
        return this.nomeDisc.getTxt (); 
    }
    
    public void setNota (float nota) {
        this.nota = nota;
    }

    public float getNota () {
        return this.nota;
    }

    public String toString () {
        return ("DISCIPLINA: "+ getDisciplina () + ", NOTA: "+ getNota ());
    } 
}
